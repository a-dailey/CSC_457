#ifndef __CLOCK_X86_H__
#define __CLOCK_X86_H__

_PROTOTYPE(int init_8253A_timer, (unsigned freq));
_PROTOTYPE(void stop_8253A_timer, (void));

#endif /* __CLOCK_X86_H__ */
