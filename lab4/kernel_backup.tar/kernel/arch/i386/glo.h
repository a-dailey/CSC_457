#ifndef __GLO_X86_H__
#define __GLO_X86_H__

EXTERN int cpu_has_tsc;	/* signal whether this cpu has time stamp register. This
			   feature was introduced by Pentium */

#endif /* __GLO_X86_H__ */
